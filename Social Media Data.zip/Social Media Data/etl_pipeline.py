# import tweepy
# import pandas as pd

# # Set up your Twitter API credentials
# consumer_key = "1o8Dkfhttx2a8wAytFgF5ybGK"
# consumer_secret = "toRXEjIid6QXptBXvU5F6NGXMoMbfGwdmrNdd1RNidZfxD0SwG"
# access_token = "1161177742676811781-CgJSF0khuNQD5WZ9S7JDqMkg3WYcqU"
# access_token_secret = "wtZKBeq8NFsBG97uhSRvdlGuLb03fSpQCaxvMHY6Sr6Yq"
# bearer_token = "AAAAAAAAAAAAAAAAAAAAAEVotgEAAAAAbs2HqwwfGhl3oEGS1JnsoV5a2S0%3D0q1Vf8yTxrW69BxkBerBYhEwAjw6iOVh0I7oEZ35bmYff9gumX"

# # Authenticate to the Twitter API
# client = tweepy.Client(bearer_token=bearer_token, consumer_key=consumer_key, 
#                        consumer_secret=consumer_secret, access_token=access_token, 
#                        access_token_secret=access_token_secret)

# # Define Elon Musk's Twitter user ID
# elon_musk_user_id = "44196397"

# # Fetch the latest tweets by Elon Musk
# tweets = client.get_users_tweets(id=elon_musk_user_id, tweet_fields=['public_metrics'], max_results=25)

# # Prepare lists to store tweet data
# tweet_texts = []
# likes = []
# retweets = []
# replies = []
# engagements = []

# # Process the tweets
# for tweet in tweets.data:
#     tweet_texts.append(tweet.text)
#     likes.append(tweet.public_metrics['like_count'])
#     retweets.append(tweet.public_metrics['retweet_count'])
#     replies.append(tweet.public_metrics['reply_count'])
#     engagements.append(tweet.public_metrics['like_count'] + tweet.public_metrics['retweet_count'] + tweet.public_metrics['reply_count'])

# # Create a DataFrame to hold the data
# df = pd.DataFrame({
#     'Tweet': tweet_texts,
#     'Likes': likes,
#     'Retweets': retweets,
#     'Replies': replies,
#     'Engagement': engagements
# })

# # Save the DataFrame to a CSV file for further analysis
# df.to_csv('elon_musk_tweets.csv', index=False)

# print("Data collection complete. Saved to elon_musk_tweets.csv")



import tweepy
import pandas as pd

# Replace with your actual Twitter API credentials
# consumer_key = "1o8Dkfhttx2a8wAytFgF5ybGK"
# consumer_secret = "toRXEjIid6QXptBXvU5F6NGXMoMbfGwdmrNdd1RNidZfxD0SwG"
# access_token = "1161177742676811781-CgJSF0khuNQD5WZ9S7JDqMkg3WYcqU"
# access_token_secret = "wtZKBeq8NFsBG97uhSRvdlGuLb03fSpQCaxvMHY6Sr6Yq"
consumer_key = '9QkflIfenAARxH9LlGEKSDuD0'
consumer_secret = 'tJPSUZEdkATTltKHmbHneyYeqZ2CHtKefeFj7MMZ54V3Poh8OW'
access_token = '1826007668433076224-xylg0UJHcEPPafjfI9Xc1xmV0Knnmz'
access_token_secret = 'RXhrjvR0xeON8jMPmOu8GOo5cwxhFgru3tH2PSSni7bOZ'



# Set up Tweepy authentication
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth, wait_on_rate_limit=True)

# Function to determine the sentiment of a tweet
def get_sentiment(text):
    if 'good' in text.lower() or 'great' in text.lower():
        return 'Positive'
    elif 'bad' in text.lower() or 'terrible' in text.lower():
        return 'Negative'
    else:
        return 'Neutral'

# Collect tweets from Elon Musk's Twitter account
tweets = api.user_timeline(screen_name='elonmusk', count=25, tweet_mode='extended')

# Prepare the dataset
data = {
    'Tweet': [],
    'Sentiment': [],
    'Topic': [],
    'Tone': [],
    'Engagement': [],
    'Source': [],
    'Likes': [],
    'Retweets': [],
    'Comments': []
}

for tweet in tweets:
    data['Tweet'].append(tweet.full_text)
    data['Sentiment'].append(get_sentiment(tweet.full_text))
    
    # Example topics based on keywords (this can be expanded or refined)
    if 'spacex' in tweet.full_text.lower():
        data['Topic'].append('Technology')
    elif 'tesla' in tweet.full_text.lower():
        data['Topic'].append('Business')
    else:
        data['Topic'].append('Other')
    
    # Example tone based on the presence of certain words (this can be refined)
    if 'lol' in tweet.full_text.lower() or 'haha' in tweet.full_text.lower():
        data['Tone'].append('Informal')
    else:
        data['Tone'].append('Formal')
    
    # Engagement as a sum of likes, retweets, and comments (estimated as tweets don't show comments count via Tweepy)
    engagement = tweet.favorite_count + tweet.retweet_count
    data['Engagement'].append(engagement)
    
    # Determine if it's an original tweet, retweet, or reply
    if hasattr(tweet, 'retweeted_status'):
        data['Source'].append('Retweet')
    elif tweet.in_reply_to_status_id is not None:
        data['Source'].append('Reply')
    else:
        data['Source'].append('Original Tweet')
    
    # Number of likes, retweets
    data['Likes'].append(tweet.favorite_count)
    data['Retweets'].append(tweet.retweet_count)
    
    # Comments count is not available directly via Tweepy, so leaving as 0 or an estimate
    data['Comments'].append(0)  # You can add an estimation or fetch comments through other means

# Convert to DataFrame
df = pd.DataFrame(data)

# Save to a CSV file
df.to_csv('elon_musk_tweets_analysis.csv', index=False)

# Display the DataFrame
print(df)
