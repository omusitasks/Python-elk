# Step 1: Load and Preprocess the Data

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset (assuming it's in CSV format)
data = pd.read_csv('X_Twitter_elon_musk_twitter_Analysis-csv.csv')

# Display the first few rows of the dataset
data.head()

# Basic data cleaning (handling missing values, data types, etc.)
data.dropna(inplace=True)
data['Sentiment(Positive/Negative/Neutral)'] = data['Sentiment(Positive/Negative/Neutral)'].astype('category')
data['Topic(Politics/Tech/Entertainment/etc.)'] = data['Topic(Politics/Tech/Entertainment/etc.)'].astype('category')
data['Tone(Formal/Informal/Sarcastic)'] = data['Tone(Formal/Informal/Sarcastic)'].astype('category')
data['Engagement Level(High/Medium/Low)'] = pd.to_numeric(data['Engagement Level(High/Medium/Low)'], errors='coerce')

# Overview of the cleaned data
data.info()


# Step 2: Sentiment and Topic Correlation
## Tabular Analysis

# Group by topic and sentiment to count occurrences
sentiment_topic_table = data.groupby(['Topic(Politics/Tech/Entertainment/etc.)', 'Sentiment(Positive/Negative/Neutral)']).size().unstack().fillna(0)
print(sentiment_topic_table)



## Bar Plot
# Plotting the correlation between sentiment and topic
plt.figure(figsize=(12, 6))
sns.countplot(data=data, x='Topic(Politics/Tech/Entertainment/etc.)', hue='Sentiment(Positive/Negative/Neutral)', palette='coolwarm')
plt.title('Sentiment Distribution Across Topics')
plt.xticks(rotation=45)
plt.show()

# Step 3: Tone and Engagement
## Scatter Plot

