# Step 1: Load and Preprocess the Data

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset (assuming it's in CSV format)
data = pd.read_csv('twitter_data.csv')

# Display the first few rows of the dataset
data.head()

# Basic data cleaning (handling missing values, data types, etc.)
data.dropna(inplace=True)
data['sentiment'] = data['sentiment'].astype('category')
data['topic'] = data['topic'].astype('category')
data['tone'] = data['tone'].astype('category')
data['engagement'] = pd.to_numeric(data['engagement'], errors='coerce')

# Overview of the cleaned data
data.info()
