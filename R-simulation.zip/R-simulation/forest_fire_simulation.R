# Task 1: Basic Forest Fire Simulation

# Install ggplot2 for visualization
install.packages("ggplot2")

# Load required library for visualization
library(ggplot2)

# Initialize the forest grid
initialize_forest <- function(N, fire_start) {
  forest <- matrix(2, nrow = N, ncol = N) # 2 = Susceptible
  forest[fire_start[1], fire_start[2]] <- 1 # 1 = Infected (Fire starts here)
  return(forest)
}

# Simulate the spread of fire
spread_fire <- function(forest, alpha, beta) {
  N <- nrow(forest)
  new_forest <- forest
  
  for (i in 1:N) {
    for (j in 1:N) {
      if (forest[i, j] == 1) { # If the cell is on fire
        # Infect neighbors with probability alpha
        neighbors <- expand.grid(
          x = c(-1, 0, 1),
          y = c(-1, 0, 1)
        )
        for (k in 1:nrow(neighbors)) {
          ni <- i + neighbors[k, "x"]
          nj <- j + neighbors[k, "y"]
          if (ni > 0 && ni <= N && nj > 0 && nj <= N && forest[ni, nj] == 2) {
            if (runif(1) < alpha) {
              new_forest[ni, nj] <- 1
            }
          }
        }
        # Remove the fire with probability beta
        if (runif(1) < beta) {
          new_forest[i, j] <- 0
        }
      }
    }
  }
  
  return(new_forest)
}

# Visualize the forest grid
visualize_forest <- function(forest, t) {
  forest_df <- as.data.frame(as.table(forest))
  colnames(forest_df) <- c("x", "y", "state")
  ggplot(forest_df, aes(x = x, y = y, fill = as.factor(state))) +
    geom_tile(color = "black") +
    scale_fill_manual(values = c("black", "red", "green"), 
                      labels = c("Burnt", "On Fire", "Susceptible"),
                      name = "State") +
    ggtitle(paste("Forest Fire Simulation at Time =", t)) +
    theme_minimal()
}

# Collect data for analysis
collect_fire_stats <- function(forest) {
  stats <- table(as.vector(forest))
  return(stats)
}

# Simulate fire spread over time
simulate_forest_fire <- function(N, alpha, beta, steps, fire_start) {
  forest <- initialize_forest(N, fire_start)
  fire_stats <- data.frame(Time = integer(), Susceptible = integer(), OnFire = integer(), Burnt = integer())
  
  for (t in 1:steps) {
    # Collect stats at each step
    stats <- collect_fire_stats(forest)
    fire_stats <- rbind(fire_stats, data.frame(
      Time = t,
      Susceptible = stats["2"],
      OnFire = stats["1"],
      Burnt = stats["0"]
    ))
    
    # Visualize the forest
    print(visualize_forest(forest, t))
    forest <- spread_fire(forest, alpha, beta)
    Sys.sleep(0.5) # Pause for visualization
  }
  
  return(fire_stats)
}

# Run the simulation
fire_stats <- simulate_forest_fire(
  N = 20,          # Grid size
  alpha = 0.5,     # Probability of spreading fire
  beta = 0.2,      # Probability of extinguishing fire
  steps = 15,      # Number of time steps
  fire_start = c(10, 10) # Starting point of fire
)

# Display statistical results
print(fire_stats)

# Plot the results
ggplot(fire_stats, aes(x = Time)) +
  geom_line(aes(y = Susceptible, color = "Susceptible")) +
  geom_line(aes(y = OnFire, color = "On Fire")) +
  geom_line(aes(y = Burnt, color = "Burnt")) +
  labs(title = "Forest Fire Simulation Over Time", y = "Cell Count", color = "State") +
  theme_minimal()








# Task 2: Forest Fire Simulation with Wind

# Install ggplot2 for visualization if not already installed
# install.packages("ggplot2")

# Load required library for visualization
library(ggplot2)

# Initialize the forest grid
initialize_forest <- function(N, fire_start) {
  forest <- matrix(2, nrow = N, ncol = N)  # 2 = Susceptible
  forest[fire_start[1], fire_start[2]] <- 1 # 1 = On Fire (initial fire start)
  return(forest)
}

# Function to incorporate wind effects on the fire spread
spread_fire_with_wind <- function(forest, alpha, beta, wind_direction) {
  N <- nrow(forest)
  new_forest <- forest
  
  # Directional spread probabilities influenced by wind direction
  wind_effect <- list(
    "N" = c(-1, 0), # North
    "S" = c(1, 0),  # South
    "E" = c(0, 1),  # East
    "W" = c(0, -1)  # West
  )
  
  wind_vector <- wind_effect[[wind_direction]]
  
  for (i in 1:N) {
    for (j in 1:N) {
      if (forest[i, j] == 1) {  # If the cell is on fire
        # Spread fire to neighboring cells
        neighbors <- expand.grid(
          x = c(-1, 0, 1),
          y = c(-1, 0, 1)
        )
        
        for (k in 1:nrow(neighbors)) {
          ni <- i + neighbors[k, "x"]
          nj <- j + neighbors[k, "y"]
          
          # Check boundaries and only spread fire to susceptible cells
          if (ni > 0 && ni <= N && nj > 0 && nj <= N && forest[ni, nj] == 2) {
            # Adjust probability based on wind direction
            prob <- alpha
            if (neighbors[k, "x"] == wind_vector[1] && neighbors[k, "y"] == wind_vector[2]) {
              prob <- prob * 1.5  # Wind amplifies the spread in the wind direction
            }
            # Spread fire based on the adjusted probability
            if (runif(1) < prob) {
              new_forest[ni, nj] <- 1
            }
          }
        }
        
        # Extinguish fire with probability beta
        if (runif(1) < beta) {
          new_forest[i, j] <- 0
        }
      }
    }
  }
  
  return(new_forest)
}

# Collecting statistics of fire states
collect_fire_stats <- function(forest) {
  stats <- table(as.vector(forest))
  return(stats)
}

# Visualize the forest grid
visualize_forest <- function(forest, t) {
  forest_df <- as.data.frame(as.table(forest))
  colnames(forest_df) <- c("x", "y", "state")
  ggplot(forest_df, aes(x = x, y = y, fill = as.factor(state))) +
    geom_tile(color = "black") +
    scale_fill_manual(values = c("black", "red", "green"), 
                      labels = c("Burnt", "On Fire", "Susceptible"),
                      name = "State") +
    ggtitle(paste("Forest Fire Simulation with Wind at Time =", t)) +
    theme_minimal()
}

# Simulate forest fire with wind
simulate_forest_fire_with_wind <- function(N, alpha, beta, steps, fire_start, wind_direction) {
  forest <- initialize_forest(N, fire_start)
  fire_stats <- data.frame(Time = integer(), Susceptible = integer(), OnFire = integer(), Burnt = integer())
  
  for (t in 1:steps) {
    # Collect stats at each step
    stats <- collect_fire_stats(forest)
    fire_stats <- rbind(fire_stats, data.frame(
      Time = t,
      Susceptible = stats["2"],
      OnFire = stats["1"],
      Burnt = stats["0"]
    ))
    
    # Visualize the forest
    print(visualize_forest(forest, t))
    
    # Update the forest state
    forest <- spread_fire_with_wind(forest, alpha, beta, wind_direction)
    
    # Pause for visualization
    Sys.sleep(0.5)
  }
  
  return(fire_stats)
}

# Run the simulation with wind (East wind in this case)
fire_stats_with_wind <- simulate_forest_fire_with_wind(
  N = 20,          # Grid size
  alpha = 0.5,     # Probability of spreading fire
  beta = 0.2,      # Probability of extinguishing fire
  steps = 15,      # Number of time steps
  fire_start = c(10, 10), # Starting point of fire
  wind_direction = "E" # Wind blowing East
)

# Display statistical results
print(fire_stats_with_wind)

# Plot the results showing the change in states over time
ggplot(fire_stats_with_wind, aes(x = Time)) +
  geom_line(aes(y = Susceptible, color = "Susceptible")) +
  geom_line(aes(y = OnFire, color = "On Fire")) +
  geom_line(aes(y = Burnt, color = "Burnt")) +
  labs(title = "Forest Fire Simulation with Wind Over Time", 
       y = "Cell Count", color = "State") +
  theme_minimal()













