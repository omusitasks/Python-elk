"""
choice = " "
while choice.lower() != 'q'
    get choice

    if choice == 'i'
        display "Enter the number of products you want to buy and your chosen price. If you buy 0-5 items, they're full price, over 5 items and each one is 10% off!"
    elif choice == 'c'
        num_product = -1
        while num_product < 0
            get num_products
            if num_products < 0
                display "Invalid input"
        price = 0
        while price <= 0
            get price
            if price <= 0
                display "Invalid input"

        total = num_products * price * (0.9 if num_products > 5 else 1)
        display num_products,price,total
    elif choice != 'q'
        display "Invalid choice"
display "Farewell"
"""



choice = ''

while choice.lower() != 'q':
    choice = input("Menu:\n(I)nstructions\n(C)alculate\n(Q)uit\nChoice: ").lower()

    if choice == 'i':
        print("Enter the number of products you want to buy and your chosen price. If you buy 0-5 items, they're full price, over 5 items and each one is 10% off!")
    elif choice == 'c':
        num_products = -1
        while num_products < 0:
            num_products = int(input("Number of products: "))
            if num_products < 0:
                print("Invalid input")

        price = 0
        while price <= 0:
            price = float(input("Price: "))
            if price <= 0:
                print("Invalid input")

        total = num_products * price * (0.9 if num_products > 5 else 1)
        print(f"{num_products} x ${price:.2f} products = ${total:.2f}")
    elif choice != 'q':
        print("Invalid choice")

print("Farewell")