"""
ONE_YEAR_OF_DOG = 10.5
TWO_YEAR_OF_DOG = 21
AGE_OF_DOG = 4

function main()
    get human_year
    while human_year > 0
        dog_years = calculate_dog_year(human_year)
        display dog_years
        get human_year

function calculate_dog_year(human_year)
    if human_year <= 2
        dog_years = human_year * ONE_YEAR_OF_DOG
    else
        dog_years = TWO_YEAR_OF_DOG + AGE_OF_DOG * (human_year - 2)
    return dog_years


main()
"""

ONE_YEAR_OF_DOG = 10.5
TWO_YEAR_OF_DOG = 21
AGE_OF_DOG = 4



def main():
    human_year = int(input("Age in human year: "))
    while human_year > 0:
        dog_years = calculate_dog_year(human_year)
        print(f"Age in dog years is {dog_years}")
        human_year = int(input("Age in human year: "))


def calculate_dog_year(human_year):
    """ calculate dog age using human age"""
    if human_year <= 2:
        dog_years = human_year * ONE_YEAR_OF_DOG
    else:
        dog_years = TWO_YEAR_OF_DOG + AGE_OF_DOG * (human_year - 2)
    return dog_years


main()
