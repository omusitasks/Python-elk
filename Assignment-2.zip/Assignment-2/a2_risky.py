"""
CP1401 2024-1 Assignment 2
Risky Business
Student Name: XX
Date started: XX

Pseudocode:

DEFAULT_LOW = 1
DEFAULT_HIGH = 10

MENU = "(P)lay, (S)et limit, (D)isplay (Q)uit: "

function main()
    low = DEFAULT_LOW
    high = DEFAULT_HIGH
    number_of_games = 0
    print welcome message
    get choice
    while choice != "Q"
        if choice == "P"
            play(low, high)
            number_of_games += 1
        else if choice == "S"
            high = set_limit(low)
        else if choice == "D"
            display(low, high)
        else
            print error message
        get choice
    print ending message, number_of_games

function play(low, high)
    secret = random number between low and high
    number_of_guesses = 1
    get guess
    while guess != secret
        number_of_guesses += 1
        if guess < secret
            print Higher
        else
            print Lower
        get guess
    print success message, number_of_guesses

function set_limit(low)
    get new_high
    while new_high <= low
        get new_high
    return new_high

function display(low,high)
    for i in range(low,high+1)
        display i
    display

function display_instructions()
    Display the game instructions.

function display_report(results)
    Display the risk-reward results report.

function show_statistics(results)
    Display statistics about the turns.

function play_turn(balance, results)
    Play a turn of the game.

function save_results(results)
    Save the results to a file.

"""

import random

# Define constants
CONSERVATIVE_CHANCE = 0.64
AGGRESSIVE_CHANCE = 0.44
SILLY_CHANCE = 0.08

CONSERVATIVE_REWARD = 0.25
AGGRESSIVE_REWARD = 0.60
SILLY_REWARD = 1.25

STARTING_BALANCE = 1234.56
RESULTS_FILE = "results.txt"

# Define functions
def display_instructions():
    """Display the game instructions."""
    print("Risky Business")
    print("Each turn, you can risk some of your cash to try and win a reward.")
    print("You can choose a risk level:")
    print("- conservative (64% chance for a +25% reward)")
    print("- aggressive (44% chance for a +60% reward)")
    print("- silly (8% chance for a +125% reward)")
    print("If your risk-taking doesn't pay off, you lose the amount you choose to risk.")
    print("Risky Business. You win some. You lose more.")
    print()

def display_report(results):
    """Display the risk-reward results report."""
    if not results:
        print("No risks taken yet. Get started...")
    else:
        print("Risk-Reward Results Report:")
        print("Starting balance: ${:.2f}".format(STARTING_BALANCE))
        for result in results:
            print("${:.2f} -> ${:.2f}".format(result, result + STARTING_BALANCE))
        print("Current balance:${:.2f}".format(results[-1] + STARTING_BALANCE))
    print()

def show_statistics(results):
    """Display statistics about the turns."""
    if not results:
        print("No risks means no statistics.")
    else:
        gains = sum(1 for result in results if result > 0)
        losses = len(results) - gains
        best_result = max(results)
        worst_result = min(results)
        win_percentage = (gains / len(results)) * 100
        loss_percentage = (losses / len(results)) * 100

        print("Best result: ${:.2f}".format(best_result))
        print("Worst result: ${:.2f}".format(worst_result))
        print("{:.1f}% ({}/{}) of your turns were gains".format(win_percentage, gains, len(results)))
        print("{:.1f}% ({}/{}) of your turns were losses".format(loss_percentage, losses, len(results)))
    print()

def play_turn(balance, results):
    """Play a turn of the game."""
    risk_amount = float(input("Enter amount to risk, up to ${:.2f}: $".format(balance)))
    while risk_amount <= 0 or risk_amount > balance:
        print("You can't risk that amount!")
        risk_amount = float(input("Enter amount to risk, up to ${:.2f}: $".format(balance)))

    risk_level = input("C)onservative, A)ggressive, S)illy: ").strip().upper()
    while risk_level not in ['C', 'A', 'S']:
        print("Please choose from the available options.")
        risk_level = input("C)onservative, A)ggressive, S)illy: ").strip().upper()

    if risk_level == 'C':
        chance = CONSERVATIVE_CHANCE
        reward = CONSERVATIVE_REWARD
    elif risk_level == 'A':
        chance = AGGRESSIVE_CHANCE
        reward = AGGRESSIVE_REWARD
    else:
        chance = SILLY_CHANCE
        reward = SILLY_REWARD

    if random.random() < chance:
        amount_won = risk_amount * reward
        print("Congratulations! You earned ${:.2f}".format(amount_won))
        balance += amount_won
    else:
        print("You lost ${:.2f}".format(risk_amount))
        balance -= risk_amount

    results.append(balance - STARTING_BALANCE)
    return balance

def save_results(results):
    """Save the results to a file."""
    with open(RESULTS_FILE, 'w') as file:
        for result in results:
            file.write("{:.2f}\n".format(result))

# Main function
def main():
    balance = STARTING_BALANCE
    results = []

    print("Welcome to Risky Business")

    while True:
        print("(P)lay")
        print("(I)nstructions")
        print("(D)isplay Report")
        print("(S)how Statistics")
        print("(Q)uit")
        choice = input("Choose: ").strip().upper()

        if choice == "P":
            balance = play_turn(balance, results)
        elif choice == "I":
            display_instructions()
        elif choice == "D":
            display_report(results)
        elif choice == "S":
            show_statistics(results)
        elif choice == "Q":
            print("Here is a summary of your", len(results), "turns.")
            display_report(results)
            save_choice = input("Would you like to save your results? [Y/n] ").strip().upper()
            if save_choice == "Y":
                save_results(results)
                print("Saved.")
            print("Thank you for playing Risky Business.")
            break
        else:
            print("Invalid choice")

if __name__ == "__main__":
    main()
