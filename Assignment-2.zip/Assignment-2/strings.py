"""
question_1()
"""
data_strings = ["Result = 95%", "Final Score = 8%", "Relative Value = 178%",
                "Something else that's very important = 9.2%", "x = 42%"]

result = "Result = 95%"
result_1 = float(result[9:11])
print(result_1)

Final_score = "Final Score = 8%"
Final_score_1 = float(Final_score[14:15])
print(Final_score_1)

relative_value = "Relative Value = 178%"
relative_value_1 = float(relative_value[17:20])
print(relative_value_1)

very_important = "Something else that's very important = 9.2%"
very_important_1 = float(very_important[39:42])
print(very_important_1)

value_x = "x = 42%"
value_x_1 = float(value_x[4:6])
print(value_x_1)

"""
question_2()
"""

dob = input("DOB: ")
born_year = int(dob[6:10])
age = 2023 - born_year
print(f"You were born in {born_year}.")
print(f'You will turn {age} in 2023.')


"""
question_3()

FIRST_YEAR = '1'
SECOND_YEAR = '2'
THIRD_YEAR = '3'
first_year_string = 'first-year'
second_year_string = 'second-year'
third_year_string = 'third-year'
master_or_other_string = 'Masters or other IT '
it_code = "CP"
it_string = ' IT'


get subject_code
while subject_code
    if subject_code[2] == FIRST_YEAR
        year_string = first_year_string
    else if subject_code[2] == SECOND_YEAR
        year_string = second_year_string
    else if subject_code[2] == THIRD_YEAR
        year_string = third_year_string
    else
        year_string = master_or_other_string
    if subject_code[:2] == it_code
        it_string = it_string
    else
        it_string = ' '
    display year_string,it_string
    get subject_code
    
"""
FIRST_YEAR = '1'
SECOND_YEAR = '2'
THIRD_YEAR = '3'
first_year_string = 'first-year'
second_year_string = 'second-year'
third_year_string = 'third-year'
master_or_other_string = 'Masters or other IT '
it_code = "CP"
it_string = ' IT'

subject_code = input("Enter subject code: ")
while subject_code:
    if subject_code[2] == FIRST_YEAR:
        year_string = first_year_string
    elif subject_code[2] == SECOND_YEAR:
        year_string = second_year_string
    elif subject_code[2] == THIRD_YEAR:
        year_string = third_year_string
    else:
        year_string = master_or_other_string

    if subject_code[:2] == it_code:
        it_string = it_string
    else:
        it_string = ''

    print(f"That is a {year_string}{it_string} subject.")
    subject_code = input("Enter subject code: ")
