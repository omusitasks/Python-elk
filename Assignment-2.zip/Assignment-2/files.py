"""
question_4()
"""
in_file = open("name.txt", "r")
text = in_file.read().strip()
print(text)


"""
question_5()

total_numbers = 0
count = 0
get file_name
open file_name for reading as in_file
get threshold
display "processing..."
for line in in_file
    number = line as float
    total_numbers = total_number + 1
    if number > threshold
        count = count + 1
close in_file
percentage = (count / total_numbers) * 100
display count,total_numbers,percentage,file_name,threshold
"""

total_numbers = 0
count = 0

file_name = input("Filename: ")
in_file = open(file_name, 'r')
threshold = float(input("Threshold: "))
print("Processing...")
for line in in_file:
    number = float(line)
    total_numbers += 1
    if number > threshold:
        count += 1
in_file.close()
percentage = (count / total_numbers) * 100
print(f'{count} out of {total_numbers} ({percentage}%) values in {file_name} are greater than {threshold}')

"""
question_6()
get input_file_name,output_file_name,search_string

open input_file_name for reading as input_file
open output_file_name for writing as output_file

for line in input_file
    if search_string in line
        output_file.write(line)
display output_file_name

input_file_close()
output_file_close()
"""

input_file_name = input("Enter the input file name: ")
output_file_name = input("Enter the output file name: ")
search_string = input("Enter the search string: ")

input_file = open(input_file_name, 'r')
output_file = open(output_file_name, 'w')


for line in input_file:
    if search_string in line:
        output_file.write(line)

print(f"Filtered lines have been written to {output_file_name}.")

input_file.close()
output_file.close()
