"""
ONE_MILE = 1.60934

function main
    speed_in_mph = get_valid_number("speed in mph")
    speed_limit_in_kph = get_valid_number("speed limit in kph")
    speed_in_kph = convert_miles_to_km(speed_in_mph)
    fine = determine_fine(speed_in_km, speed_limit_in_kph)
    print fine

function get_valid_number(prompt,low)
    get input_number
    while input_number < low
       display Invalid Number
        get input_number
    return input_number

function convert_miles_to_km(speed_in_mph)
    speed_in_kph = ONE_MILE * speed_in_mph
    return speed_in_kph


function determine_fine(speed_in_kph, speed_limit_in_kph)
    speed_over_limit = speed_in_kph - speed_limit_in_kph
    if speed_over_limit <= 0
        return 0
    elif speed_over_limit < 11
        return 309
    elif speed_over_limit <= 20
        return 464
    elif speed_over_limit <= 30
        return 696
    elif speed_over_limit <= 40
        return 1161
    else
        return 1780

main()

"""

ONE_MILE = 1.60934


def main():
    speed_in_mph = get_valid_number("speed in mph: ", 0)
    speed_limit_in_kph = get_valid_number("speed limit in kph: ", 0)
    speed_in_kph = convert_miles_to_km(speed_in_mph)
    fine = determine_fine(speed_in_kph, speed_limit_in_kph)
    print(f'The fine you have to pay is ${fine}')


def get_valid_number(prompt, low):
    """check the number is valid or not"""
    input_number = int(input(prompt))
    while input_number < low:
        print("Invalid Number")
        input_number = int(input(prompt))
    return input_number


def convert_miles_to_km(speed_in_mph):
    """ covert miles into km"""
    speed_in_kph = ONE_MILE * speed_in_mph
    return speed_in_kph


def determine_fine(speed_in_kph, speed_limit_in_kph):
    """determine how much the car goes over speed"""
    speed_over_limit = speed_in_kph - speed_limit_in_kph
    if speed_over_limit <= 0:
        return 0
    elif speed_over_limit <= 10:
        return 309
    elif speed_over_limit <= 20:
        return 464
    elif speed_over_limit <= 30:
        return 696
    elif speed_over_limit <= 40:
        return 1161
    else:
        return 1780


main()
