"""
UNDERWEIGHT = 18.5
NORMAL = 25
OVERWEIGHT = 30

function main()
    file_name = "bmis.txt."
    get number_people
    write_bmis_to_file(file_name,number_people)
    read_bmis_from_file(file_name)

function calculate_bmi(height,weight)
    return weight / (height **2)

function get_weight_category(bmi)
        if bmi < UNDERWEIGHT
        return "underweight"
    else if bmi < NORMAL
        return "normal"
    else if bmi < OVERWEIGHT
        return "overweight"
    else
        return "obese"

function write_bmi_to_file(file_name, number_people)
    open filename for writing as file
    for i in range(number_people)
        get height,weight
        bmi = calculate_bmi(height, weight)
        file.write(f"{bmi}\n")
    close file

def get_valid_number(prompt, low, high)
    get number
    while number < low or number > high
        display "Invalid input"
        get number
    return number

function read_bmi_from_file(file_name)
    open filename for reading as file
    for line in file
        bmi = float(line.strip())
        weight_category = determine_weight_category(bmi)
        display bmi,weight_category
    close file

main()

"""
UNDERWEIGHT = 18.5
NORMAL = 25
OVERWEIGHT = 30


def main():
    file_name = "bmis.txt"
    number_people = int(input("How many people?: "))
    write_bmi_to_file(file_name, number_people)
    read_bmi_from_the_file(file_name)



def write_bmi_to_file(file_name, number_people):
    # Calculate the bmi with the information obtained from the height and weight and write it in a file.
    file = open(file_name, 'w')
    for i in range(number_people):
        height = get_valid_number("Height (m): ", 0, 3)
        weight = get_valid_number("Weight (kg): ", 0, 300)
        bmi = calculate_bmi(height, weight)
        file.write(f"{bmi}\n")
    file.close()


def read_bmi_from_the_file(file_name):
    # read bmi from the file
    file = open(file_name, 'r')
    for line in file:
        bmi = float(line.strip())
        weight_category = determine_weight_category(bmi)
        print(f'BMI {bmi}, considered {weight_category}')
    file.close()




def get_valid_number(prompt, low, high):
    # check the input number is valid or not
    number = float(input(prompt))
    while number < low or number > high:
        print("Invalid input")
        number = float(input(prompt))
    return number


def calculate_bmi(height, weight):
    # calculate the bmi
    return weight / (height ** 2)


def determine_weight_category(bmi):
    # determine bmi category by weight
    if bmi < UNDERWEIGHT:
        return "underweight"
    if bmi < NORMAL:
        return "normal"
    if bmi < OVERWEIGHT:
        return "overweight"
    return "obese"


main()

