# Import wage.csv 
da <- read.csv("wage.csv")
da


# Eq 1
m1 <- lm(log(wage) ~ educ + exper, data = da) 
summary(m1)
AIC(m1)
BIC(m1)


# Eq 2
higheduc <- ifelse(da$educ > 12, 1, 0) 
m2 <- lm(log(wage) ~ higheduc + exper, data = da) 
summary(m2)
AIC(m2)
BIC(m2)



# Eq 3
m3 <- lm(log(wage) ~ educ + I(educ^2) + exper + I(exper^2) + educ:exper, data = da)  
summary(m3)
AIC(m3)
BIC(m3)
