
# Load required libraries
library(dplyr)
library(tidyr)
library(broom)

# Import wage.csv 
# Load data
da <- read.csv("wage.csv")
da

############################### EQUATION 1 #################################
# Eq 1

# Define indicator variable higheduc
da$higheduc <- ifelse(da$educ > 12, 1, 0)


# Equation 1: ln(wage) = β1 + β2*educ + β3*exper + e
m1 <- lm(log(wage) ~ educ + exper, data = da)

# Extract coefficients and format them into a table
coef_table <- tidy(m1) %>%
  filter(term != "(Intercept)") %>%  # Exclude intercept from the table
  select(term, estimate, std.error, statistic, p.value)

# Transpose the coefficient table
coef_table <- t(as.matrix(coef_table))

# Set column names
colnames(coef_table) <- coef_table[1, ]

# Remove term row
coef_table <- coef_table[-1, ]

# Rename the row names
row.names(coef_table) <- c("Estimate", "Std.Error", "t value", "Pr(>|t|)")

# Print the table
print(coef_table)

# Other statistics for Equation 1
N <- length(da$wage)
adj_r_squared <- summary(m1)$adj.r.squared
AIC_val <- AIC(m1)
BIC_val <- BIC(m1)

# Create a data frame for the statistics
statistics_df <- data.frame(
  Equation = "Eq. (1)",
  N = N,
  `Adj. R^2` = adj_r_squared,
  AIC = AIC_val,
  BIC = BIC_val
)

# Print the statistics table
print(statistics_df)


############################### EQUATION 2 #################################

# Eq 2
# Equation 2: ln(wage) = β1 + β2*higheduc + β3*exper + e
m2 <- lm(log(wage) ~ higheduc + exper, data = da)

# Extract coefficients and format them into a table
coef_table_eq2 <- tidy(m2) %>%
  filter(term != "(Intercept)") %>%  # Exclude intercept from the table
  select(term, estimate, std.error, statistic, p.value)

# Transpose the coefficient table
coef_table_eq2 <- t(as.matrix(coef_table_eq2))

# Set column names
colnames(coef_table_eq2) <- coef_table_eq2[1, ]

# Remove term row
coef_table_eq2 <- coef_table_eq2[-1, ]

# Rename the row names
row.names(coef_table_eq2) <- c("Estimate", "Std.Error", "t value", "Pr(>|t|)")

# Print the table for Equation 2
print(coef_table_eq2)

# Other statistics for Equation 2
N_eq2 <- length(da$wage)
adj_r_squared_eq2 <- summary(m2)$adj.r.squared
AIC_val_eq2 <- AIC(m2)
BIC_val_eq2 <- BIC(m2)

# Create a data frame for the statistics for Equation 2
statistics_df_eq2 <- data.frame(
  Equation = "Eq. (2)",
  N = N_eq2,
  `Adj. R^2` = adj_r_squared_eq2,
  AIC = AIC_val_eq2,
  BIC = BIC_val_eq2
)

# Print the statistics table for Equation 2
print(statistics_df_eq2)

############################### EQUATION 3 #################################

# Eq 3
# Equation 3: ln(wage) = β1 + β2*educ + β3*educ^2 + β4*exper + β5*exper^2 + β6*(educ*exper) + e
m3 <- lm(log(wage) ~ educ + I(educ^2) + exper + I(exper^2) + educ:exper, data = da)

# Extract coefficients and format them into a table
coef_table_eq3 <- tidy(m3) %>%
  filter(term != "(Intercept)") %>%  # Exclude intercept from the table
  select(term, estimate, std.error, statistic, p.value)

# Transpose the coefficient table
coef_table_eq3 <- t(as.matrix(coef_table_eq3))

# Set column names
colnames(coef_table_eq3) <- coef_table_eq3[1, ]

# Remove term row
coef_table_eq3 <- coef_table_eq3[-1, ]

# Rename the row names
row.names(coef_table_eq3) <- c("Estimate", "Std.Error", "t value", "Pr(>|t|)")

# Print the table for Equation 3
print(coef_table_eq3)

# Other statistics for Equation 3
N_eq3 <- length(da$wage)
adj_r_squared_eq3 <- summary(m3)$adj.r.squared
AIC_val_eq3 <- AIC(m3)
BIC_val_eq3 <- BIC(m3)

# Create a data frame for the statistics for Equation 3
statistics_df_eq3 <- data.frame(
  Equation = "Eq. (3)",
  N = N_eq3,
  `Adj. R^2` = adj_r_squared_eq3,
  AIC = AIC_val_eq3,
  BIC = BIC_val_eq3
)

# Print the statistics table for Equation 3
print(statistics_df_eq3)



############################### Wage Equation Estimates #################################

# Wage Equation Estimates
# Define indicator variable higheduc
da$higheduc <- ifelse(da$educ > 12, 1, 0)

# Equation 1: ln(wage) = β1 + β2*educ + β3*exper + e
m1 <- lm(log(wage) ~ educ + exper, data = da)
summary(m1)

# Equation 2: ln(wage) = β1 + β2*higheduc + β3*exper + e
m2 <- lm(log(wage) ~ higheduc + exper, data = da)
summary(m2)

# Equation 3: ln(wage) = β1 + β2*educ + β3*educ^2 + β4*exper + β5*exper^2 + β6*(educ*exper) + e
m3 <- lm(log(wage) ~ educ + I(educ^2) + exper + I(exper^2) + educ:exper, data = da)
summary(m3)

# Table presentation of results
table_results <- bind_rows(
  data.frame(Variable = c("(Intercept)", "educ", "exper"), 
             `Eq. (1)` = c(coef(m1)[1], coef(m1)[2], coef(m1)[3]), 
             `Eq. (2)` = c(coef(m2)[1], coef(m2)[2], coef(m2)[3]), 
             `Eq. (3)` = c(coef(m3)[1], coef(m3)[2], coef(m3)[4])),
  data.frame(Variable = c("educ^2", "higheduc", "exper^2", "educ*exper"), 
             `Eq. (1)` = c(NA, NA, NA, NA), 
             `Eq. (2)` = c(NA, coef(m2)[2], NA, NA), 
             `Eq. (3)` = c(coef(m3)[3], NA, coef(m3)[5], coef(m3)[6])),
  data.frame(Variable = c("N", "Adj. R^2", "AIC", "BIC"), 
             `Eq. (1)` = c(1000, summary(m1)$adj.r.squared, AIC(m1), BIC(m1)), 
             `Eq. (2)` = c(1000, summary(m2)$adj.r.squared, AIC(m2), BIC(m2)), 
             `Eq. (3)` = c(1000, summary(m3)$adj.r.squared, AIC(m3), BIC(m3)))
)

# Print the table
print(table_results)

# Other statistics
N <- length(da$wage)
adj_r_squared <- c(summary(m1)$adj.r.squared, summary(m2)$adj.r.squared, summary(m3)$adj.r.squared)
AIC_val <- c(AIC(m1), AIC(m2), AIC(m3))
BIC_val <- c(BIC(m1), BIC(m2), BIC(m3))

# Report other statistics
cat("\nOther Statistics:\n")
cat("N:", N, "\n")
cat("Adj. R^2:", adj_r_squared, "\n")
cat("AIC:", AIC_val, "\n")
cat("BIC:", BIC_val, "\n")

