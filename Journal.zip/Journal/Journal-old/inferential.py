import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

#  to perform statistical tests
from scipy import stats
from scipy.stats import chi2_contingency

# Load the dataset
file_path = 'final.csv'  # Adjust this path as needed
df = pd.read_csv(file_path)
# Hypothesis 3: Effect of Data Analytics on Decision-Making

decision_making_col = '12.  What benefits has your organization experienced from using data analytics? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Informed decision-making]'
data_analytics_col = '6.  Which of the following technologies has your organization adopted? (Select all that apply) '

# Filter data
df['DataAnalyticsAdopted'] = df[data_analytics_col].apply(lambda x: 'Data Analytics' in x)

# Perform t-test for decision-making
decision_making_ratings = df[['DataAnalyticsAdopted', decision_making_col]].dropna()
group1 = decision_making_ratings[decision_making_ratings['DataAnalyticsAdopted']][decision_making_col]
group2 = decision_making_ratings[~decision_making_ratings['DataAnalyticsAdopted']][decision_making_col]

# Check if groups are empty before performing t-test
if len(group1) > 0 and len(group2) > 0:
    t_stat, p_value = stats.ttest_ind(group1, group2)

    print(f"T-Statistic: {t_stat}")
    print(f"P-Value: {p_value}")

    if p_value < 0.05:
        print("Reject the null hypothesis: The use of data analytics significantly affects decision-making.")
    else:
        print("Fail to reject the null hypothesis: The use of data analytics does not significantly affect decision-making.")
else:
    print("One or both groups are empty. Check data and column names.")