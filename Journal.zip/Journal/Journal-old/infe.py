import pandas as pd
import scipy.stats as stats

# Load dataset
df = pd.read_csv("final.csv")

# # Chi-square Test: Examining the relationship between technology adoption and societal equity contribution
# tech_adoption = df["6.  Which of the following technologies has your organization adopted? (Select all that apply) "]
# societal_equity = df["7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Contribution to societal equity (e.g., bridging digital divides)]"]

# # Convert categorical variables into numeric representations
# tech_encoded = tech_adoption.astype("category").cat.codes
# equity_encoded = societal_equity.astype("category").cat.codes

# # Perform Chi-square test
# chi2, p_value, _, _ = stats.chi2_contingency(pd.crosstab(tech_encoded, equity_encoded))
# print(f"Chi-square Test for Technology Adoption vs. Societal Equity Contribution:")
# print(f"Chi-square Statistic: {chi2:.3f}, P-value: {p_value:.5f}")



# Convert the necessary columns to numeric values (handling missing values gracefully)
df["9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Ethical concerns]"] = pd.to_numeric(
    df["9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Ethical concerns]"], 
    errors='coerce'
)

df["7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Contribution to societal equity (e.g., bridging digital divides)]"] = pd.to_numeric(
    df["7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Contribution to societal equity (e.g., bridging digital divides)]"], 
    errors='coerce'
)

# Drop rows with missing data in the relevant columns
df.dropna(subset=[
    "9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Ethical concerns]",
    "7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Contribution to societal equity (e.g., bridging digital divides)]"
], inplace=True)

# Focus on industry and size groups for the analysis
# Hypothesis 1: Ethical concerns across industries
ethical_concerns = df["9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Ethical concerns]"]
industry = df["2.  Which industry does your organization belong to? "]

# Perform ANOVA on ethical concerns across industries
industry_groups = [ethical_concerns[industry == group] for group in industry.unique()]
anova_stat, anova_p = stats.f_oneway(*industry_groups)

print("\nANOVA Test for Ethical Concerns across Industries:")
print(f"F-statistic: {anova_stat:.3f}, P-value: {anova_p:.5f}")

# # Hypothesis 2: Impact on societal equity across organization sizes
# societal_impact = df["7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Contribution to societal equity (e.g., bridging digital divides)]"]
# organization_size = df["3.  What is the size of your organization? "]

# # Perform ANOVA on societal impact across organization sizes
# size_groups = [societal_impact[organization_size == size] for size in organization_size.unique()]
# anova_stat_size, anova_p_size = stats.f_oneway(*size_groups)

# print("\nANOVA Test for Societal Equity Impact across Organization Sizes:")
# print(f"F-statistic: {anova_stat_size:.3f}, P-value: {anova_p_size:.5f}")

# # Output findings
# if anova_p < 0.05:
#     print("\nThere is a significant difference in ethical concerns across industries.")
# else:
#     print("\nThere is no significant difference in ethical concerns across industries.")

# if anova_p_size < 0.05:
#     print("\nThere is a significant difference in the impact of digital transformation on societal equity across organization sizes.")
# else:
#     print("\nThere is no significant difference in the impact of digital transformation on societal equity across organization sizes.")

# # print(df.columns)