import pandas as pd
import scipy.stats as stats
import numpy as np

# Load dataset
df = pd.read_csv("final.csv")

# # Convert necessary columns to numeric values
# df["Ethical Concerns"] = pd.to_numeric(
#     df["9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Ethical concerns]"], 
#     errors='coerce'
# )

# df["Industry"] = df["2.  Which industry does your organization belong to? "]

# # Drop rows with missing data in relevant columns
# df.dropna(subset=["Ethical Concerns", "Industry"], inplace=True)

# # Group data by industry
# groups = [df["Ethical Concerns"][df["Industry"] == group] for group in df["Industry"].unique()]

# # Compute ANOVA statistics
# anova_stat, anova_p = stats.f_oneway(*groups)

# # Total number of observations
# N = len(df)

# # Number of groups
# k = len(groups)

# # Compute Sum of Squares Between Groups (SSB)
# group_means = [np.mean(group) for group in groups]
# overall_mean = np.mean(df["Ethical Concerns"])
# SSB = sum(len(group) * (mean - overall_mean) ** 2 for group, mean in zip(groups, group_means))

# # Compute Sum of Squares Within Groups (SSW)
# SSW = sum(sum((group - mean) ** 2) for group, mean in zip(groups, group_means))

# # Compute Degrees of Freedom
# df_between = k - 1
# df_within = N - k

# # Compute Mean Squares
# MSB = SSB / df_between
# MSW = SSW / df_within

# # Print ANOVA Table Values
# print("\nANOVA Test for Ethical Concerns across Industries:")
# print(f"Sum of Squares Between (SSB): {SSB:.3f}")
# print(f"Sum of Squares Within (SSW): {SSW:.3f}")
# print(f"Degrees of Freedom Between (df1): {df_between}")
# print(f"Degrees of Freedom Within (df2): {df_within}")
# print(f"Mean Square Between (MSB): {MSB:.3f}")
# print(f"Mean Square Within (MSW): {MSW:.3f}")
# print(f"F-statistic: {anova_stat:.3f}")
# print(f"P-value: {anova_p:.5f}")



# Convert the necessary columns to numeric values (handling missing values gracefully)
df["9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Ethical concerns]"] = pd.to_numeric(
    df["9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Ethical concerns]"], 
    errors='coerce'
)

df["7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Contribution to societal equity (e.g., bridging digital divides)]"] = pd.to_numeric(
    df["7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Contribution to societal equity (e.g., bridging digital divides)]"], 
    errors='coerce'
)

# Drop rows with missing data in the relevant columns
df.dropna(subset=[
    "9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Ethical concerns]",
    "7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Contribution to societal equity (e.g., bridging digital divides)]"
], inplace=True)


# Focus on industry and size groups for the analysis
# Hypothesis 1: Ethical concerns across industries
ethical_concerns = df["9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Ethical concerns]"]
industry = df["2.  Which industry does your organization belong to? "]


# Perform ANOVA on ethical concerns across industries
industry_groups = [ethical_concerns[industry == group] for group in industry.unique()]
anova_stat, anova_p = stats.f_oneway(*industry_groups)

# Hypothesis 2: Impact on societal equity across organization sizes
societal_impact = df["7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Contribution to societal equity (e.g., bridging digital divides)]"]
organization_size = df["3.  What is the size of your organization? "]

# Perform ANOVA on societal impact across organization sizes
size_groups = [societal_impact[organization_size == size] for size in organization_size.unique()]
anova_stat_size, anova_p_size = stats.f_oneway(*size_groups)

print("\nANOVA Test for Societal Equity Impact across Organization Sizes:")
print(f"F-statistic: {anova_stat_size:.3f}, P-value: {anova_p_size:.5f}")

# Output findings
if anova_p < 0.05:
    print("\nThere is a significant difference in ethical concerns across industries.")
else:
    print("\nThere is no significant difference in ethical concerns across industries.")

if anova_p_size < 0.05:
    print("\nThere is a significant difference in the impact of digital transformation on societal equity across organization sizes.")
else:
    print("\nThere is no significant difference in the impact of digital transformation on societal equity across organization sizes.")

# print(df.columns)