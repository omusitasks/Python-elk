
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

#  to perform statistical tests
from scipy import stats
from scipy.stats import chi2_contingency

# Load the dataset
file_path = 'JournalQuestionnaire.csv'  # Adjust this path as needed
df = pd.read_csv(file_path)

# Print the column names
# print(df.columns)


# Select the numerical columns and rename them for better readability
numerical_columns = {
    '7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Operational efficiency]': 'Operational Efficiency',
    '7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Customer experience]': 'Customer Experience',
    '7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Competitiveness]': 'Competitiveness',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Lack of skilled personnel]': 'Lack of Skilled Personnel',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [High implementation costs]': 'High Implementation Costs',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Resistance to change]': 'Resistance to Change',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Data security concerns]': 'Data Security Concerns',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Inadequate infrastructure]': 'Inadequate Infrastructure',
    '12.  What benefits has your organization experienced from using data analytics? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Informed decision-making]': 'Informed Decision-Making',
    '12.  What benefits has your organization experienced from using data analytics? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Improved operational efficiency]': 'Improved Operational Efficiency',
    '12.  What benefits has your organization experienced from using data analytics? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Enhanced customer experience]': 'Enhanced Customer Experience',
    '12.  What benefits has your organization experienced from using data analytics? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Increased competitiveness]': 'Increased Competitiveness',
    '15.  What benefits has your organization gained from these collaborations? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Access to specialized expertise]': 'Access to Specialized Expertise',
    '15.  What benefits has your organization gained from these collaborations? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Access to cutting-edge resources]': 'Access to Cutting-Edge Resources',
    '15.  What benefits has your organization gained from these collaborations? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Accelerated digital transformation]': 'Accelerated Digital Transformation',
    '17.  How effective are these strategies in promoting a digital-first culture in your organization? (Rate on a scale of 1 to 5, where 1 is not effective and 5 is highly effective)  [Leadership commitment to digital initiatives]': 'Leadership Commitment to Digital Initiatives',
    '17.  How effective are these strategies in promoting a digital-first culture in your organization? (Rate on a scale of 1 to 5, where 1 is not effective and 5 is highly effective)  [Continuous learning and development programs]': 'Continuous Learning and Development',
    '17.  How effective are these strategies in promoting a digital-first culture in your organization? (Rate on a scale of 1 to 5, where 1 is not effective and 5 is highly effective)  [Incentives for innovation]': 'Incentives for Innovation',
    '17.  How effective are these strategies in promoting a digital-first culture in your organization? (Rate on a scale of 1 to 5, where 1 is not effective and 5 is highly effective)  [Cross-functional teams for digital projects]': 'Cross-Functional Teams for Digital Projects',
    '19.  Overall, how successful has your organization’s digital transformation been? (Rate on a scale of 1 to 5, where 1 is not successful and 5 is highly successful) ': 'Overall Digital Transformation Success'
}

# Rename the columns
df.rename(columns=numerical_columns, inplace=True)

# Select only the renamed columns
df_numerical = df[list(numerical_columns.values())]

# Calculate descriptive statistics
descriptive_stats = df_numerical.describe().T

# Display the table
print(descriptive_stats)
# print(df.columns)