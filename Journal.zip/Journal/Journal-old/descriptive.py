import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

#  to perform statistical tests
from scipy import stats
from scipy.stats import chi2_contingency

# Load the dataset
file_path = 'final.csv'  # Adjust this path as needed
df = pd.read_csv(file_path)

# Print the column names
# print(df.columns)


# Select the numerical columns and rename them for better readability
numerical_columns = {
    '7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Operational efficiency]': 'Operational Efficiency',
    '7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Customer experience]': 'Customer Experience',
    '7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Competitiveness]': 'Competitiveness',
    '7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Contribution to societal equity (e.g., bridging digital divides)]': 'Contribution to societal equity (e.g., bridging digital divides)',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Lack of skilled personnel]': 'Lack of Skilled Personnel',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [High implementation costs]': 'High Implementation Costs',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Resistance to change]': 'Resistance to Change',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Data security and privacy concerns]': 'Data security and privacy concerns',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Ethical concerns]': 'Ethical concerns',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Inadequate infrastructure]': 'Inadequate Infrastructure',
    '12.  What benefits has your organization experienced from using data analytics? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Informed decision-making]': 'Informed Decision-Making',
    '12.  What benefits has your organization experienced from using data analytics? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Improved operational efficiency]': 'Improved Operational Efficiency',
    '12.  What benefits has your organization experienced from using data analytics? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Enhanced customer experience]': 'Enhanced Customer Experience',
    '12.  What benefits has your organization experienced from using data analytics? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Increased competitiveness]': 'Increased Competitiveness',
    '12.  What benefits has your organization experienced from using data analytics? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Improved societal impact]': 'Improved societal impact',
    '15.  What benefits has your organization gained from these collaborations? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Access to specialized expertise]': 'Access to Specialized Expertise',
    '15.  What benefits has your organization gained from these collaborations? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Access to cutting-edge resources]': 'Access to Cutting-Edge Resources',
    '15.  What benefits has your organization gained from these collaborations? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Accelerated digital transformation]': 'Accelerated Digital Transformation',
    '15.  What benefits has your organization gained from these collaborations? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Contributions to societal and ethical goals]': 'Contributions to societal and ethical goals',
    '17.  How effective are these strategies in promoting a digital-first culture in your organization? (Rate on a scale of 1 to 5, where 1 is not effective and 5 is highly effective)  [Leadership commitment to digital initiatives]': 'Leadership Commitment to Digital Initiatives',
    '17.  How effective are these strategies in promoting a digital-first culture in your organization? (Rate on a scale of 1 to 5, where 1 is not effective and 5 is highly effective)  [Continuous learning and development programs]': 'Continuous Learning and Development',
    '17.  How effective are these strategies in promoting a digital-first culture in your organization? (Rate on a scale of 1 to 5, where 1 is not effective and 5 is highly effective)  [Incentives for innovation]': 'Incentives for Innovation',
    '17.  How effective are these strategies in promoting a digital-first culture in your organization? (Rate on a scale of 1 to 5, where 1 is not effective and 5 is highly effective)  [Cross-functional teams for digital projects]': 'Cross-Functional Teams for Digital Projects',
    '17.  How effective are these strategies in promoting a digital-first culture in your organization? (Rate on a scale of 1 to 5, where 1 is not effective and 5 is highly effective)  [Inclusion programs]': 'Inclusion programs',
    '19.  Overall, how successful has your organization’s digital transformation been? (Rate on a scale of 1 to 5, where 1 is not successful and 5 is highly successful) ': 'Overall Digital Transformation Success'
}

# Rename the columns
df.rename(columns=numerical_columns, inplace=True)

# Select only the renamed columns
df_numerical = df[list(numerical_columns.values())]


df_numerical = df_numerical.apply(pd.to_numeric, errors='coerce')

# Calculate descriptive statistics
descriptive_stats = df_numerical.describe().T

# Display the table
# print(descriptive_stats)

# descriptive_stats.to_csv('descriptive_statistics.csv')
# print("Descriptive statistics saved to 'descriptive_statistics.csv'")

# Save to an Excel file
descriptive_stats.to_excel('descriptive_statistics.xlsx', index=True)
print("Descriptive statistics saved to 'descriptive_statistics.xlsx'")




# print("Columns after renaming:")
# print(df_numerical.columns)

# print(df_numerical.dtypes)

# print(df_numerical.isna().sum())
# df_numerical = df_numerical.fillna(df_numerical.mean())  
# print(df_numerical.isna().sum())


