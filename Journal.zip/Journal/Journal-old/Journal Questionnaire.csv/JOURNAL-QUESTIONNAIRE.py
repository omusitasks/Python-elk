import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

#  to perform statistical tests
from scipy import stats
from scipy.stats import chi2_contingency

# Load the dataset
file_path = 'JournalQuestionnaire.csv'  # Adjust this path as needed
df = pd.read_csv(file_path)


# Print the column names
print(df.columns)

# GRAPH 1: BAR GRAPH Success of Digital Transformation

# Access the 'Organization success' column
org_success_data = df['19.  Overall, how successful has your organization’s digital transformation been? (Rate on a scale of 1 to 5, where 1 is not successful and 5 is highly successful) ']

# Create a dictionary with the frequency of each age group
org_success_data_distribution = org_success_data.value_counts().to_dict()

# Plot the bar chart
plt.figure(figsize=(10, 6))
plt.bar(org_success_data_distribution.keys(), org_success_data_distribution.values(), color='skyblue')
plt.title('Distribution of Success Ratings for Digital Transformation')
plt.xlabel('Success Rating (1-5)')
plt.ylabel('Number of Organizations')
plt.xticks(rotation=0)
plt.show()



#  GRAPH 2: Line Plot for Impact of Technology Adoption

# # Create a new DataFrame for technology impact
impact_df = df[['7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Operational efficiency]', 
                '7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Customer experience]',
                '7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Competitiveness]']]

# Plot the line chart
plt.figure(figsize=(10, 6))
impact_df.mean().plot(kind='line', marker='o')
plt.title('Impact of Technology Adoption on Organizational Aspects')
plt.xlabel('Aspect')
plt.ylabel('Average Impact (1-5)')

# Adjust x-ticks to display fully
plt.xticks(np.arange(3), ['Operational Efficiency', 'Customer Experience', 'Competitiveness'], rotation=15, ha='right')

# Apply tight layout to avoid cutting off labels
plt.ylim(1, 5)
plt.tight_layout()
plt.show()


# GRAPH 3: Stacked Bar Chart for Technology Adoption

# Create a new DataFrame for technology adoption
technologies = ['Cloud computing', 'Data Analytics', 'Mobile applications', 
                'Artificial intelligence', 'Internet of Things (IoT)', 'Blockchain']

# Count the occurrences of each technology adoption
tech_counts = pd.DataFrame()
for tech in technologies:
    tech_counts[tech] = df['6.  Which of the following technologies has your organization adopted? (Select all that apply) '].apply(lambda x: tech in x).value_counts(normalize=True)

# Plot the stacked bar chart
tech_counts.transpose().plot(kind='bar', stacked=True, figsize=(6, 6))
plt.title('Technology Adoption Across Organizations')
plt.xlabel('Technology')
plt.ylabel('Proportion of Organizations')
plt.legend(['Not Adopted', 'Adopted'], loc='upper right')

# Adjust x-ticks to display fully
plt.xticks(rotation=15, ha='right')

plt.tight_layout()
plt.show()


# GRAPH 4:  Pie Chart for Organization Size

# Count the number of organizations by size
size_counts = df['3.  What is the size of your organization? '].value_counts()

# Plot the pie chart
plt.figure(figsize=(8, 8))
size_counts.plot(kind='pie', autopct='%1.1f%%', startangle=140)
plt.title('Distribution of Organizations by Size')
plt.ylabel('')
plt.show()


# GRAPH 5: Bar Chart for Industry Distribution

# Count the number of organizations per industry
industry_counts = df['2.  Which industry does your organization belong to? '].value_counts()

# Plot the bar chart
plt.figure(figsize=(10, 6))
industry_counts.plot(kind='bar')
plt.title('Distribution of Organizations by Industry')
plt.xlabel('Industry')
plt.ylabel('Number of Organizations')
plt.xticks(rotation=15)
plt.show()


# Analyze DEMOGRAPHICS
# GRAPH 6-1: Organization Size

# Count the size of organizations
organization_size = df['3.  What is the size of your organization? '].value_counts()

# Plot the organization size distribution
plt.figure(figsize=(8, 6))
sns.barplot(x=organization_size.index, y=organization_size.values, palette="viridis")
plt.title('Distribution of Organization Sizes')
plt.xlabel('Organization Size')
plt.ylabel('Number of Organizations')
plt.show()



# GRAPH 6-2: Industry

# Count the industry types
industry_counts = df['2.  Which industry does your organization belong to? '].value_counts()

# Plot the industry distribution
plt.figure(figsize=(10, 8))
sns.barplot(x=industry_counts.values, y=industry_counts.index, palette="magma")
plt.title('Distribution of Industries')
plt.xlabel('Number of Organizations')
plt.ylabel('Industry')
plt.show()


# GRAPH 6-3: Position

# Count the number of respondents per position
position_counts = df['4.  What is your position within the organization? '].value_counts()

# Plot the bar chart
plt.figure(figsize=(10, 6))
position_counts.plot(kind='bar')
plt.title('Distribution of Positions within the Organization')
plt.xlabel('Position')
plt.ylabel('Number of Respondents')
plt.xticks(rotation=15)
plt.tight_layout()
plt.show()



# GRAPH 7: Digital Transformation Motivations
# Analyze the reasons for digital transformation
motivation_columns = ['5.  What are the primary reasons your organization decided to pursue digital transformation? (Select all that apply) ']
df_motivation = df[motivation_columns].copy()

# Split the multiple choice answers into separate rows
df_motivation = df_motivation[motivation_columns[0]].str.get_dummies(';')

# Summarize the motivations
motivation_summary = df_motivation.sum().sort_values(ascending=False)

# Plot the motivations for digital transformation
plt.figure(figsize=(10, 6))
sns.barplot(x=motivation_summary.values, y=motivation_summary.index, palette="coolwarm")
plt.title('Primary Reasons for Digital Transformation')
plt.xlabel('Number of Organizations')
plt.ylabel('Motivation')
plt.yticks(rotation=65)
plt.show()



# GRAPH 8: Barriers to Digital Transformation

# Analyze the barriers to digital transformation
barrier_columns = [
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Lack of skilled personnel]',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [High implementation costs]',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Resistance to change]',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Data security concerns]',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Inadequate infrastructure]'
]

plt.figure(figsize=(12, 8))

for i, col in enumerate(barrier_columns, 1):
    plt.subplot(3, 2, i)
    sns.countplot(x=df[col], palette="Set3")
    plt.title(col.split('[')[1].split(']')[0])
    plt.xlabel('Barrier Significance')
    plt.ylabel('Count')

plt.tight_layout()
plt.show()


# GRAPH 9: Data Analytics Usage
# Areas of Data Analytics Application

# Analyze areas of data analytics application
analytics_columns = ['11.  In which areas does your organization leverage data analytics? (Select all that apply) ']
df_analytics = df[analytics_columns].copy()

# Split the multiple choice answers into separate rows
df_analytics = df_analytics[analytics_columns[0]].str.get_dummies(';')

# Summarize the data analytics usage areas
analytics_summary = df_analytics.sum().sort_values(ascending=False)

# Plot the data analytics usage areas
plt.figure(figsize=(8, 6))
sns.barplot(x=analytics_summary.values, y=analytics_summary.index, palette="Blues")
plt.title('Areas of Data Analytics Application')
plt.xlabel('Number of Organizations')
plt.ylabel('Application Area')
plt.yticks(rotation=65)
plt.show()


# GRAPH 10: 

# 10. Significant of these Barriers to Digital Transformation
# Define the columns related to barriers
barrier_columns = [
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Lack of skilled personnel]',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [High implementation costs]',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Resistance to change]',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Data security concerns]',
    '9.  How significant are these barriers in hindering your organization’s digital transformation? (Rate on a scale of 1 to 5, where 1 is not significant and 5 is very significant)  [Inadequate infrastructure]'
]

# Plotting the barriers
plt.figure(figsize=(16, 12))

for i, col in enumerate(barrier_columns, 1):
    plt.subplot(3, 2, i)
    sns.countplot(x=df[col], palette="Set3")
    plt.title(col.split('[')[1].split(']')[0])
    plt.xlabel('Barrier Significance')
    plt.ylabel('Count')
    plt.xticks(rotation=45)

plt.tight_layout(pad=4.0)  # Adjust the padding between subplots
plt.show()


# GRAPH 12:

# Assuming 'df' is your DataFrame and contains the column for the question on data analytics usage
question_column = '10.  How extensively does your organization use data analytics for decision-making? '

# Plotting the count plot
plt.figure(figsize=(10, 6))
sns.countplot(x=df[question_column], palette="Set3")

# Adding a title and labels
plt.title('Extent of Data Analytics Usage for Decision-Making')
plt.xlabel('Usage Frequency')
plt.ylabel('Number of Organizations')

# Rotating the x-ticks for better readability
plt.xticks(rotation=15)
plt.tight_layout()

# Display the plot
plt.show()


# GRAPH 13:

# Column corresponding to the question
question_column = '11.  In which areas does your organization leverage data analytics? (Select all that apply) '

# Define the possible areas of data analytics usage
areas = [
    'Customer insights and personalization',
    'Operational optimization',
    'Market trend analysis',
    'Product development',
    'Risk management',
    # 'Other (please specify)'
]

# Create a DataFrame to count the occurrences of each area
area_counts = pd.Series({area: df[question_column].str.contains(area).sum() for area in areas})

# Plot the bar chart
plt.figure(figsize=(10, 6))
sns.barplot(x=area_counts.index, y=area_counts.values, palette="Set3")

# Add a title and labels
plt.title('Areas Where Organizations Leverage Data Analytics')
plt.xlabel('Area')
plt.ylabel('Number of Organizations')

# Rotate the x-ticks for better readability
plt.xticks(rotation=15, ha='right')
plt.tight_layout()

# Display the plot
plt.show()



# GRAPH 14:

# Define the columns for each benefit
benefit_columns = {
    'Informed decision-making': '12.  What benefits has your organization experienced from using data analytics? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Informed decision-making]',
    'Improved operational efficiency': '12.  What benefits has your organization experienced from using data analytics? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Improved operational efficiency]',
    'Enhanced customer experience': '12.  What benefits has your organization experienced from using data analytics? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Enhanced customer experience]',
    'Increased competitiveness': '12.  What benefits has your organization experienced from using data analytics? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Increased competitiveness]',
}

# Calculate the average rating for each benefit
benefit_averages = {benefit: df[column].mean() for benefit, column in benefit_columns.items()}

# Create a DataFrame from the averages
benefit_df = pd.DataFrame(list(benefit_averages.items()), columns=['Benefit', 'Average Rating'])

# Plot the bar chart
plt.figure(figsize=(12, 6))
sns.barplot(x='Benefit', y='Average Rating', data=benefit_df, palette="Set2")

# Add a title and labels
plt.title('Benefits Experienced from Using Data Analytics')
plt.xlabel('Benefit')
plt.ylabel('Average Rating (1-5)')

# Rotate the x-ticks for better readability
plt.xticks(rotation=15, ha='right')
plt.ylim(1, 5)
plt.tight_layout()

# Display the plot
plt.show()


# HYPOTHESIS TESTS

# Hypothesis 1: Impact of Technology Adoption on Operational Efficiency

# Grouping based on whether 'Cloud computing' is adopted or not


# Assuming 'Operational efficiency' is a column in the dataset
# Compare operational efficiency between those who adopted 'Cloud computing' and those who did not

# Group 1: Adopted Cloud computing
group1 = df[df['6.  Which of the following technologies has your organization adopted? (Select all that apply) '].str.contains('Cloud computing')]['7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Operational efficiency]']

# Group 2: Did not adopt Cloud computing
group2 = df[~df['6.  Which of the following technologies has your organization adopted? (Select all that apply) '].str.contains('Cloud computing')]['7.  How has the adoption of these technologies impacted your organization? (Rate on a scale of 1 to 5, where 1 is not at all and 5 is significant)  [Operational efficiency]']

# Perform t-test
t_stat, p_value = stats.ttest_ind(group1.dropna(), group2.dropna())

# Print the results
print(f"t-statistic: {t_stat}, p-value: {p_value}")

if p_value < 0.05:
    print("Reject the null hypothesis: Significant difference in operational efficiency based on cloud computing adoption.")
else:
    print("Fail to reject the null hypothesis: No significant difference in operational efficiency based on cloud computing adoption.")


# Hypothesis 2: Impact of Organization Size on Technology Adoption

# Preprocess the data for organization size and technology adoption
# Mapping for technology adoption and organization size
technology_adopted = ['Cloud computing', 'Data Analytics', 'Mobile applications', 'Artificial intelligence', 'Internet of Things (IoT)', 'Blockchain', 'Other']
df['TechnologyAdopted'] = df['6.  Which of the following technologies has your organization adopted? (Select all that apply) '].apply(lambda x: [tech for tech in technology_adopted if tech in x])

# Create contingency table for organization size and technology adoption
contingency_table = pd.crosstab(df['3.  What is the size of your organization? '], pd.Series([tech for sublist in df['TechnologyAdopted'] for tech in sublist]))

# Perform Chi-Square Test
chi2_stat, p_value, dof, expected = stats.chi2_contingency(contingency_table)

print(f"Chi-Square Statistic: {chi2_stat}")
print(f"P-Value: {p_value}")

if p_value < 0.05:
    print("Reject the null hypothesis: There is an association between organization size and the types of technology adopted.")
else:
    print("Fail to reject the null hypothesis: There is no association between organization size and the types of technology adopted.")

# Assess the effect of data analytics on decision-making
# Identify correct column names for decision-making ratings
# Print columns to find relevant names
print(df.columns)

# Hypothesis 3: Effect of Data Analytics on Decision-Making

decision_making_col = '12.  What benefits has your organization experienced from using data analytics? (Rate on a scale of 1 to 5, where 1 is not beneficial and 5 is highly beneficial)  [Informed decision-making]'
data_analytics_col = '6.  Which of the following technologies has your organization adopted? (Select all that apply) '

# Filter data
df['DataAnalyticsAdopted'] = df[data_analytics_col].apply(lambda x: 'Data Analytics' in x)

# Perform t-test for decision-making
decision_making_ratings = df[['DataAnalyticsAdopted', decision_making_col]].dropna()
group1 = decision_making_ratings[decision_making_ratings['DataAnalyticsAdopted']][decision_making_col]
group2 = decision_making_ratings[~decision_making_ratings['DataAnalyticsAdopted']][decision_making_col]

# Check if groups are empty before performing t-test
if len(group1) > 0 and len(group2) > 0:
    t_stat, p_value = stats.ttest_ind(group1, group2)

    print(f"T-Statistic: {t_stat}")
    print(f"P-Value: {p_value}")

    if p_value < 0.05:
        print("Reject the null hypothesis: The use of data analytics significantly affects decision-making.")
    else:
        print("Fail to reject the null hypothesis: The use of data analytics does not significantly affect decision-making.")
else:
    print("One or both groups are empty. Check data and column names.")



